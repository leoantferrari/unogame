package Game;

/**
 * The Class which includes a main to start the game
 * 
 * @author Leo Ferrari
 *
 */
public class Test {
	/**
	 * the main method that starts the game
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		Game game = new Game();

	}
}

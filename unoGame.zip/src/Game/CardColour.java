package Game;

/**
 * An enum used to for the card colours, easier than a String.
 * 
 * @author leoan
 *
 */
public enum CardColour {

	RED, BLUE, GREEN, YELLOW

}
